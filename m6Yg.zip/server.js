// server.js
//
// Backend for the LMArena Bridge Telegram Mini App.
// Node/Express port of contend_BRIDGE_main.py's dashboard routes, with the
// original password-form login replaced by Telegram initData verification
// (see telegramAuth.js). This is the piece that must run on a server that
// holds BOT_TOKEN — it can never ship to the browser bundle (App.js).
//
// Endpoints (all JSON in/out unless noted):
//   POST /api/auth/verify     { initData }              -> { user }            (sets session cookie)
//   POST /api/auth/logout                                -> { ok: true }
//   GET  /api/state           [auth]                     -> full dashboard state
//   POST /api/keys            [auth] { name, rpm }        -> created key
//   DELETE /api/keys/:key                        [auth]   -> { ok: true }
//   POST /api/tokens          [auth] { token }            -> { ok: true }
//   DELETE /api/tokens/:index [auth]                      -> { ok: true }
//   POST /api/refresh         [auth]                      -> refreshed state (stub: wire to real arena fetch)

require("dotenv").config();
const express = require("express");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const { verifyTelegramInitData } = require("./telegramAuth");
const { readConfig, writeConfig } = require("./store");

const {
  BOT_TOKEN,
  SESSION_JWT_SECRET,
  SESSION_TTL_HOURS = "24",
  INITDATA_MAX_AGE_HOURS = "24",
  CORS_ORIGINS = "*",
  PORT = "8787",
} = process.env;

if (!BOT_TOKEN || !SESSION_JWT_SECRET) {
  console.error(
    "FATAL: BOT_TOKEN and SESSION_JWT_SECRET must be set (see .env.example). Refusing to start."
  );
  process.exit(1);
}

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use(
  cors({
    origin: CORS_ORIGINS === "*" ? true : CORS_ORIGINS.split(",").map((s) => s.trim()),
    credentials: true,
  })
);

const SESSION_COOKIE = "session";

/* ---------------------------------------------------------------------- */
/* Auth                                                                    */
/* ---------------------------------------------------------------------- */

app.post("/api/auth/verify", (req, res) => {
  const { initData } = req.body || {};
  const result = verifyTelegramInitData(initData, BOT_TOKEN, Number(INITDATA_MAX_AGE_HOURS));

  if (!result.valid) {
    return res.status(401).json({ ok: false, reason: result.reason });
  }

  const token = jwt.sign(
    { uid: result.user.id, user: result.user },
    SESSION_JWT_SECRET,
    { expiresIn: `${SESSION_TTL_HOURS}h` }
  );

  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: true,
    sameSite: "none",
    maxAge: Number(SESSION_TTL_HOURS) * 60 * 60 * 1000,
  });

  return res.json({ ok: true, user: result.user });
});

app.post("/api/auth/logout", (req, res) => {
  res.clearCookie(SESSION_COOKIE);
  res.json({ ok: true });
});

function requireAuth(req, res, next) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return res.status(401).json({ ok: false, reason: "no_session" });
  try {
    req.session = jwt.verify(token, SESSION_JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ ok: false, reason: "invalid_session" });
  }
}

/* ---------------------------------------------------------------------- */
/* Dashboard state (mirrors config.json from the Python version)          */
/* ---------------------------------------------------------------------- */

function toDashboardState(config) {
  const hasAuthToken =
    Boolean(String(config.auth_token || "").trim()) || (config.auth_tokens || []).length > 0;
  return {
    api_keys: config.api_keys,
    auth_tokens: config.auth_tokens,
    has_auth_token: hasAuthToken,
    cf_clearance_configured: Boolean(config.cf_clearance),
    models: config.models,
    usage: config.usage,
    total_requests: Object.values(config.usage || {}).reduce((a, b) => a + b, 0),
  };
}

app.get("/api/state", requireAuth, (req, res) => {
  res.json(toDashboardState(readConfig()));
});

/* ---------------------------------------------------------------------- */
/* API keys — mirrors /create-key, /delete-key                            */
/* ---------------------------------------------------------------------- */

app.post("/api/keys", requireAuth, (req, res) => {
  const { name, rpm } = req.body || {};
  const cleanName = String(name || "").trim();
  if (!cleanName) return res.status(400).json({ ok: false, reason: "name_required" });

  const config = readConfig();
  const newKey = {
    name: cleanName,
    key: `sk-lmab-${crypto.randomUUID()}`,
    rpm: Math.max(1, Math.min(Number(rpm) || 60, 1000)),
    created: new Date().toISOString(),
  };
  config.api_keys.push(newKey);
  writeConfig(config);
  res.status(201).json({ ok: true, key: newKey });
});

app.delete("/api/keys/:key", requireAuth, (req, res) => {
  const config = readConfig();
  config.api_keys = config.api_keys.filter((k) => k.key !== req.params.key);
  writeConfig(config);
  res.json({ ok: true });
});

/* ---------------------------------------------------------------------- */
/* Arena auth tokens — mirrors /add-auth-token, /delete-auth-token        */
/* ---------------------------------------------------------------------- */

app.post("/api/tokens", requireAuth, (req, res) => {
  const token = String(req.body?.token || "").trim();
  if (!token) return res.status(400).json({ ok: false, reason: "token_required" });

  const config = readConfig();
  if (!config.auth_tokens.includes(token)) config.auth_tokens.push(token);
  writeConfig(config);
  res.status(201).json({ ok: true });
});

app.delete("/api/tokens/:index", requireAuth, (req, res) => {
  const idx = Number(req.params.index);
  const config = readConfig();
  if (idx >= 0 && idx < config.auth_tokens.length) {
    config.auth_tokens.splice(idx, 1);
    writeConfig(config);
  }
  res.json({ ok: true });
});

/* ---------------------------------------------------------------------- */
/* Refresh — mirrors /refresh-tokens (stub: plug in your real arena fetch) */
/* ---------------------------------------------------------------------- */

app.post("/api/refresh", requireAuth, async (req, res) => {
  // TODO: port get_initial_data() from the Python bridge here — fetch a
  // fresh cf_clearance + model list from LMArena and persist via writeConfig.
  const config = readConfig();
  res.json({ ok: true, state: toDashboardState(config) });
});

app.listen(Number(PORT), () => {
  console.log(`LMArena Bridge TG backend listening on :${PORT}`);
});
